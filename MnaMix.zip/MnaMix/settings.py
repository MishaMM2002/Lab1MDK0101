# Global
DEBUG = True
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 5000

# Server settings
DATABASE_PATH = './src/database/database.db'
SQL_SCRIPTS_DIR = './src/database/'
