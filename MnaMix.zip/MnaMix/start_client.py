from src.client.mainwindow import MainWindow


if __name__ == '__main__':
    root = MainWindow()
    root.title("Наша база")
    root.geometry('800x600')
    root.mainloop()
